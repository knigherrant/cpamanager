DROP TABLE IF EXISTS `#__cpamanager_bibles`;
DROP TABLE IF EXISTS `#__cpamanager_comments`;
DROP TABLE IF EXISTS `#__cpamanager_config`;
DROP TABLE IF EXISTS `#__cpamanager_events`;
DROP TABLE IF EXISTS `#__cpamanager_links`;
DROP TABLE IF EXISTS `#__cpamanager_profiles`;
DROP TABLE IF EXISTS `#__cpamanager_requests`;
DROP TABLE IF EXISTS `#__cpamanager_warriors`;





